#include "ros/ros.h"
#include <iostream>
#include "nav_msgs/Odometry.h"

using namespace std;
//#include <sstream>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "setflags");
    ros::NodeHandle n;

    ros::Rate loop_rate(30);

    ros::Publisher flag_pub = n.advertise<nav_msgs::Odometry>("/cyb_flags", 10);

    // int count = 0;
    int type;
    float radius;
    float x,y,z, yaw;
    while (ros::ok())
    {
        nav_msgs::Odometry msg;
        
        //std::stringstream ss;
        // ss<<"hello world "<<count;
        cout<<"input type :1-flyTo001,2-flytoxyz,3-fastPlanner"<<endl;
        cin>>type;
        if(type == 1){
            msg.child_frame_id = "1";
            flag_pub.publish(msg);
        }
        else if(type == 2){
            msg.child_frame_id = "2";
            
	cout << "mode 2, input x,y,z, yaw:" << endl;
            cin >> x >> y >> z >> yaw;
            msg.pose.pose.position.x = x;
            msg.pose.pose.position.y = y;
            msg.pose.pose.position.z = z;
            msg.pose.pose.orientation.z = yaw;

            flag_pub.publish(msg);
        }
        else if(type == 3){
            msg.child_frame_id = "3";
            flag_pub.publish(msg);
        }
        else{
            ;
        }

        ros::spinOnce();

        loop_rate.sleep();
        // ++count;
    }

    return 0;
}
