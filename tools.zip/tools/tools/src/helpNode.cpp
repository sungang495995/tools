
#include "ros/ros.h"
#include <iostream>
#include "nav_msgs/Odometry.h"
#include<mavros_msgs/PositionTarget.h>

#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>

#include <Eigen/Eigen>
#include <Eigen/Dense>
#include "apriltag_ros/common_functions.h"
#include "apriltag_ros/continuous_detector.h"
#include <apriltag_ros/AprilTagDetectionArray.h>
#include <apriltag_ros/AprilTagDetection.h>
using namespace std;

bool start_fly = false;
double fly_start_time = 0.0;
ros::Publisher tag_pub;
Eigen::Vector3d tag_pos_cam, tag_pos_uav, tag_pos_world;
Eigen::Quaterniond tag_orient_cam, tag_orient_uav, tag_orient_world, mavori;
int flag;
float x_target, y_target, z_target, yaw_target;
Eigen::Vector3d mavp;
bool getTagpos = false;
double cur_yaw_;
void tagCallback(const apriltag_ros::AprilTagDetectionArray::ConstPtr& msg)
{
  //return;
  if(msg -> detections.size() == 0) return;
  getTagpos = true;
  int tagID = 0;
  tag_pos_cam(0) = msg->detections[0].pose.pose.pose.position.x;
  tag_pos_cam(1) = msg->detections[0].pose.pose.pose.position.y;
  tag_pos_cam(2) = msg->detections[0].pose.pose.pose.position.z;
  tag_orient_cam.w() = msg->detections[0].pose.pose.pose.orientation.w;
  tag_orient_cam.x() = msg->detections[0].pose.pose.pose.orientation.x;
  tag_orient_cam.y() = msg->detections[0].pose.pose.pose.orientation.y;
  tag_orient_cam.z() = msg->detections[0].pose.pose.pose.orientation.z;
  
  //tagID = msg->detections[0].id[0];
  //计算码在无人机系下的位置,相机infra与无人机外参
  tag_pos_uav(0) = tag_pos_cam(1);
  tag_pos_uav(1) = tag_pos_cam(0);
  tag_pos_uav(2) = tag_pos_cam(2);
  //计算码在世界系下的位置
  Eigen::Matrix3d R;
  R = mavori.normalized().toRotationMatrix();
  tag_pos_world = mavp + R * tag_pos_uav;
}

void flagCallbck(const nav_msgs::Odometry& msg) {
  if(msg.child_frame_id == "1"){
      flag = 1;
  }
  else if(msg.child_frame_id == "2"){
      flag = 2;
      x_target = msg.pose.pose.position.x;
      y_target = msg.pose.pose.position.y;
      z_target = msg.pose.pose.position.z;
      yaw_target = msg.pose.pose.orientation.z;
  }
  else if(msg.child_frame_id == "3"){
      flag = 3;
  }
  else if(msg.child_frame_id == "4"){
      flag = 4;
  }
  else{
      ;
  }
}



//接收里程计信息
void mavposCallbck(const geometry_msgs::PoseStamped& msg){

mavp(0) = msg.pose.position.x;
mavp(1) = msg.pose.position.y;
mavp(2) = msg.pose.position.z;

mavori.w() = msg.pose.orientation.w;
mavori.x() = msg.pose.orientation.x;
mavori.y() = msg.pose.orientation.y;
mavori.z() = msg.pose.orientation.z;
Eigen::Vector3d rot_x = mavori.toRotationMatrix().block(0, 0, 3, 1);
cur_yaw_ = atan2(rot_x(1), rot_x(0));
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "helpnode");


    ros::NodeHandle n;

    ros::Subscriber flag_sub = n.subscribe("/cyb_flags", 50, flagCallbck);
    ros::Publisher  vec_pub=n.advertise<mavros_msgs::PositionTarget>("/mavros/setpoint_raw/local", 6);
      tag_sub = nh.subscribe("/tag_detections", 10, &tagCallback);

    ros::Subscriber mavpose = n.subscribe("/mavros/local_position/pose", 50, mavposCallbck);

    flag = 0;
    x_target = 0;
    y_target = 0;
    z_target = 0.6;
    yaw_target = 0;

    ros::Rate loop_rate(100);

    mavros_msgs::PositionTarget msg;
    msg.header.stamp = ros::Time::now();
    static int seq = 1;
    msg.header.seq = seq++;
    msg.header.frame_id = 1;
    msg.coordinate_frame = mavros_msgs::PositionTarget::FRAME_LOCAL_NED;
    msg.type_mask = mavros_msgs::PositionTarget::IGNORE_PX +
                    mavros_msgs::PositionTarget::IGNORE_PY +
                    mavros_msgs::PositionTarget::IGNORE_PZ +
                    mavros_msgs::PositionTarget::IGNORE_AFX +
                    mavros_msgs::PositionTarget::IGNORE_AFY +
                    mavros_msgs::PositionTarget::IGNORE_AFZ +
                    mavros_msgs::PositionTarget::FORCE +
                    // mavros_msgs::PositionTarget::IGNORE_YAW;
                    mavros_msgs::PositionTarget::IGNORE_YAW_RATE;
    nav_msgs::Odometry fast_flag;
    fast_flag.child_frame_id = "0";

    static tf::TransformListener listener;
    tf::StampedTransform transform;
    while (ros::ok())
    {
        /*try{
            // listener.lookupTransform("/world_modified", "/body_modified", ros::Time(0), transform);
            // listener.lookupTransform("/camera_odom_frame", "/camera_link", ros::Time(0), transform);
            listener.lookupTransform("/t265_odom_frame", "/t265_link", ros::Time(0), transform);
            //cout << "success odom" << endl;
        }
        catch (tf::TransformException &ex) {
            cout << "fail odom" << endl;
            ROS_ERROR("%s",ex.what());
            continue;
        }*/

        tf::Quaternion q = transform.getRotation();
        tf::Vector3 t = transform.getOrigin();
        Eigen::Vector3d pos_cyb;
        pos_cyb(0) = t.x();
        pos_cyb(1) = t.y();
        pos_cyb(2) = t.z();
        if(flag == 1){//flyTo001.5
            fast_flag.child_frame_id = "0";
            doube target_x = getTagpos == true ? tag_pos_world(0) : 0;
            doube target_y = getTagpos == true ? tag_pos_world(1) : 0;
            Eigen::Vector3d delta_xyz;
            delta_xyz(0) = target_x - mavp(0);
            delta_xyz(1) = target_y - mavp(1);
            delta_xyz(2) = 1.5 - mavp(2);
            msg.velocity.x = 0.95 * delta_xyz(0);
            msg.velocity.y = 0.95 * delta_xyz(1);
            msg.velocity.z = 1.0  * delta_xyz(2);
            msg.velocity.z = msg.velocity.z > 0.5 ? 0.5 : msg.velocity.z;
            msg.velocity.y = msg.velocity.y > 0.5 ? 0.5 : msg.velocity.y;
            msg.velocity.x = msg.velocity.x > 0.5 ? 0.5 : msg.velocity.x;
            msg.yaw = 0;
            vec_pub.publish(msg);
        }
        else if(flag == 2){//tracking 
            fast_flag.child_frame_id = "0";

            Eigen::Vector3d delta_xyz;
            delta_xyz(0) = tag_pos_world(0) - mavp(0);
            delta_xyz(1) = tag_pos_world(1) - mavp(1);
            delta_xyz(2) = 1.50 - mavp(2);
            Eigen::Matrix3d r;

            msg.velocity.x = 0.95 * delta_xyz(0);
            msg.velocity.y = 0.95 * delta_xyz(1);
            msg.velocity.z = 1.0  * delta_xyz(2);
            msg.velocity.x = msg.velocity.x > 0.5 ? 0.5 : msg.velocity.x;
            msg.velocity.y = msg.velocity.y > 0.5 ? 0.5 : msg.velocity.y;
            msg.velocity.z = msg.velocity.z > 0.5 ? 0.5 : msg.velocity.z;
            double ts_yaw = atan2(rot_x(1), rot_x(0)) + M_PI_2;
            msg.yaw = yaw_target;
            vec_pub.publish(msg);
            // cout << "delta_xyz: " << endl << delta_xyz << endl;
            // cout << "msg.yaw: " << endl << msg.yaw << endl;
        }

        ros::spinOnce();

        loop_rate.sleep();
        // ++count;
    }

    return 0;
}
