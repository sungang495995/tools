#include <ros/ros.h>
#include <std_msgs/String.h>
#include <stdio.h>
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Vector3Stamped.h"
#include<vector>

int main(int argc, char **argv)
{
   ros::init(argc, argv, "pub_setpoints");
   ros::NodeHandle n;

   ros::Publisher chatter_pub = n.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local",6);
   ros::Rate loop_rate(10);
   ros::spinOnce();

   geometry_msgs::PoseStamped msg;
   int count = 1;

        //PositionReciever qp;:
        //Body some_object;
        //qp.connect_to_server();

    std::vector<std::vector<double>> waypoints{{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    int p=0;
   while(ros::ok()){
       //some_object = qp.getStatus();
        // some_object.print();
       msg.header.stamp = ros::Time::now();
       msg.header.seq=count;
       msg.header.frame_id = 1;
       msg.pose.position.x = 0; //waypoints[p][0];//0.001*some_object.position_x;
       msg.pose.position.y = 0; //waypoints[p][1];//0.001*some_object.position_y;
       msg.pose.position.z = 0.6; //waypoints[p][2];//0.001*some_object.position_z;
       msg.pose.orientation.x = 0;
       msg.pose.orientation.y = 0;
       msg.pose.orientation.z = 0;
       msg.pose.orientation.w = 1;

       chatter_pub.publish(msg);
       ros::spinOnce();
/*
       count++;
       if(count>50){
           p++;
           p=p%4;
           count=1;
       }
*/
       loop_rate.sleep();
   }
   return 0;
}
