
#include "ros/ros.h"
#include <iostream>
#include "nav_msgs/Odometry.h"
#include<mavros_msgs/PositionTarget.h>

#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>

#include <Eigen/Eigen>
#include <Eigen/Dense>

using namespace std;
//#include <sstream>

double x_target[100] = {};
double y_target[100] = {};
double z_target[100] = {};
double yaw_target[100] = {};



int flag;
float x_target, y_target, z_target, yaw_target;

void flagCallbck(const nav_msgs::Odometry& msg) {
  if(msg.child_frame_id == "1"){
      flag = 1;
  }
  else if(msg.child_frame_id == "2"){
      flag = 2;
      x_target = msg.pose.pose.position.x;
      y_target = msg.pose.pose.position.y;
      z_target = msg.pose.pose.position.z;
      yaw_target = msg.pose.pose.orientation.z;
  }
  else if(msg.child_frame_id == "3"){
      flag = 3;
  }
  else{
      ;
  }
}

Eigen::Vector3d mavp;

void mavposCallbck(const geometry_msgs::PoseStamped& msg){

mavp(0) = msg.pose.position.x;
mavp(1) = msg.pose.position.y;
mavp(2) = msg.pose.position.z;

}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "helpnode");


    ros::NodeHandle n;

    ros::Subscriber flag_sub = n.subscribe("/cyb_flags", 50, flagCallbck);
    ros::Publisher  vec_pub=n.advertise<mavros_msgs::PositionTarget>("/mavros/setpoint_raw/local", 6);
    ros::Publisher  fastPlannerFlag_pub=n.advertise<nav_msgs::Odometry>("/fastplannerflag", 6);

ros::Subscriber mavpose = n.subscribe("/mavros/local_position/pose", 50, mavposCallbck);

    flag = 0;
    x_target = 0;
    y_target = 0;
    z_target = 0.6;
    yaw_target = 0;

    ros::Rate loop_rate(100);

    mavros_msgs::PositionTarget msg;
    msg.header.stamp = ros::Time::now();
    static int seq = 1;
    msg.header.seq = seq++;
    msg.header.frame_id = 1;
    msg.coordinate_frame = mavros_msgs::PositionTarget::FRAME_LOCAL_NED;
    msg.type_mask = mavros_msgs::PositionTarget::IGNORE_PX +
                    mavros_msgs::PositionTarget::IGNORE_PY +
                    mavros_msgs::PositionTarget::IGNORE_PZ +
                    mavros_msgs::PositionTarget::IGNORE_AFX +
                    mavros_msgs::PositionTarget::IGNORE_AFY +
                    mavros_msgs::PositionTarget::IGNORE_AFZ +
                    mavros_msgs::PositionTarget::FORCE +
                    // mavros_msgs::PositionTarget::IGNORE_YAW;
                    mavros_msgs::PositionTarget::IGNORE_YAW_RATE;
    nav_msgs::Odometry fast_flag;
    fast_flag.child_frame_id = "0";

    static tf::TransformListener listener;
    tf::StampedTransform transform;
    while (ros::ok())
    {
        try{
            // listener.lookupTransform("/world_modified", "/body_modified", ros::Time(0), transform);
            // listener.lookupTransform("/camera_odom_frame", "/camera_link", ros::Time(0), transform);
            listener.lookupTransform("/t265_odom_frame", "/t265_link", ros::Time(0), transform);
            //cout << "success odom" << endl;
        }
        catch (tf::TransformException &ex) {
            cout << "fail odom" << endl;
            ROS_ERROR("%s",ex.what());
            continue;
        }

        tf::Quaternion q = transform.getRotation();
        tf::Vector3 t = transform.getOrigin();
        Eigen::Vector3d pos_cyb;
        pos_cyb(0) = t.x();
        pos_cyb(1) = t.y();
        pos_cyb(2) = t.z();
        if(flag == 0){
            fast_flag.child_frame_id = "0";

        }
        else if(flag == 1){//flyTo001
            fast_flag.child_frame_id = "0";

            Eigen::Vector3d delta_xyz;
            delta_xyz(0) = 0 - pos_cyb(0);
            delta_xyz(1) = 0 - pos_cyb(1);
            delta_xyz(2) = 1 - pos_cyb(2);
            Eigen::Matrix3d r;
            r << 0, -1, 0, 1, 0, 0, 0, 0, 1;
            delta_xyz = r*delta_xyz; //from t265 frame to px4 local frame

            msg.velocity.x = 0.95 * delta_xyz(0);
            msg.velocity.y = 0.95 * delta_xyz(1);
            msg.velocity.z = 1.0  * delta_xyz(2);
            msg.yaw = 0 + M_PI/2.0;
            vec_pub.publish(msg);
        }
        else if(flag == 2){//2-flytoxyz
            fast_flag.child_frame_id = "0";

            Eigen::Vector3d delta_xyz;
            delta_xyz(0) = x_target - pos_cyb(0);
            delta_xyz(1) = y_target - pos_cyb(1);
            delta_xyz(2) = z_target - pos_cyb(2);
            Eigen::Matrix3d r;
            r << 0, -1, 0, 1, 0, 0, 0, 0, 1;
            delta_xyz = r*delta_xyz; //from t265 frame to px4 local frame

            msg.velocity.x = 0.95 * delta_xyz(0);
            msg.velocity.y = 0.95 * delta_xyz(1);
            msg.velocity.z = 1.0  * delta_xyz(2);
            msg.yaw = yaw_target + M_PI/2.0;
            vec_pub.publish(msg);
            // cout << "delta_xyz: " << endl << delta_xyz << endl;
            // cout << "msg.yaw: " << endl << msg.yaw << endl;
        }
        else if(flag == 3){
            // nav_msgs::Odometry fast_flag;
            fast_flag.child_frame_id = "1";
        }
        

        fastPlannerFlag_pub.publish(fast_flag);

        ros::spinOnce();

        loop_rate.sleep();
        // ++count;
    }

    return 0;
}



/*
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <stdio.h>
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Vector3Stamped.h"
#include<vector>

int main(int argc, char **argv)
{
   ros::init(argc, argv, "helpnode");
   ros::NodeHandle n;

   ros::Publisher chatter_pub = n.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local",6);
   ros::Rate loop_rate(10);
   ros::spinOnce();

   geometry_msgs::PoseStamped msg;
   int count = 1;

        //PositionReciever qp;:
        //Body some_object;
        //qp.connect_to_server();

    std::vector<std::vector<double>> waypoints{{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    int p=0;
   while(ros::ok()){
       //some_object = qp.getStatus();
        // some_object.print();
       msg.header.stamp = ros::Time::now();
       msg.header.seq=count;
       msg.header.frame_id = 1;
       msg.pose.position.x = waypoints[p][0];//0.001*some_object.position_x;
       msg.pose.position.y = waypoints[p][1];//0.001*some_object.position_y;
       msg.pose.position.z = waypoints[p][2];//0.001*some_object.position_z;
       msg.pose.orientation.x = 0;
       msg.pose.orientation.y = 0;
       msg.pose.orientation.z = 0;
       msg.pose.orientation.w = 1;

       chatter_pub.publish(msg);
       ros::spinOnce();
       count++;
       if(count>50){
           p++;
           p=p%4;
           count=1;
       }
       loop_rate.sleep();
   }
   return 0;
}
*/
